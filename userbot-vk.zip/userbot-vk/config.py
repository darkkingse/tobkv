# токен пользователя (vk.cc/a6dCgm)
access_token = "vk1.a.qkJAoa2m8ZMGE9sANagQWE43mSBAB9rcQ6vyOPHsyE_ibKUlCbTwz2JoOvWfeg_0xbvurctq40lvJPdbjiIGrdq03Yj33zfwob_d39rL507qpcSmpuDtuUMxjJ0i3HyZ9KrixgP-7tpnXPqBAkkgiI70FduxqTjS3gtw9kmF2ivb942r9_uPcA9ScP4446vJ"
log_messages = True  # логировать ли сообщения

prefixes = {  # префиксы, перед сообщениями
    "error": "❗",  # Ошибка при использовании
    "invalid": "⚠️",  # Какой-то недочет в запросе
    "process": "⚡ ",  # Испоьзуется когда процесс может выполняться долгое время
    "success": "✅ ",  # Используется когда все прошло успешно
    "success_no": "❎"  # Используется когда все прошло успешно, но ответ отрицательный
}

odeanon_token = False

# токен пользователя (vk.cc/a6dCgm)
access_token = "vk1.a.XZpgymKrptdebWLmnWU9BQhyfk22EGp7tRZYzP5P6y5TrLTt40cEN2ZqF-XXNPFvL5xzIuqbWK1kpweds6MAnxH5O3gGwAp1RFv_1Juv7hKo6LElbI8qmY-fnd4YiAcSm_pyvp4mvvzqZBkBdynOCpenn9q2UYLysfMOaO-kvyvU856qKUGFOubZ8qzCyLWL"
log_messages = True  # логировать ли сообщения

prefixes = {  # префиксы, перед сообщениями
    "error": "❗",  # Ошибка при использовании
    "invalid": "⚠️",  # Какой-то недочет в запросе
    "process": "⚡ ",  # Испоьзуется когда процесс может выполняться долгое время
    "success": "✅ ",  # Используется когда все прошло успешно
    "success_no": "❎"  # Используется когда все прошло успешно, но ответ отрицательный
}

odeanon_token = False

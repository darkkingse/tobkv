# токен пользователя (vk.cc/a6dCgm)
access_token = "vk1.a.lUgRZudBhDUf8HIaYlRVDKJhA3gGBCbQiuZB67lI7HPFJsqloldz1LCKLKIl5jQqZYTka9LH2vZsXGoUi9mOjAfUoDJfyZqtcZJ8AVduvqd_9zvU8SxIrlWFVp2yuiFe8Mu5LfvmeDC4T7aElreRgrY0noX3kKSxEvztW_cdFWB-Yc1jHLtBuyueJKX1FXDS"
log_messages = True  # логировать ли сообщения

prefixes = {  # префиксы, перед сообщениями
    "error": "❗",  # Ошибка при использовании
    "invalid": "⚠️",  # Какой-то недочет в запросе
    "process": "⚡ ",  # Испоьзуется когда процесс может выполняться долгое время
    "success": "✅ ",  # Используется когда все прошло успешно
    "success_no": "❎"  # Используется когда все прошло успешно, но ответ отрицательный
}

odeanon_token = False

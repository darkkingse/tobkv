import time
import datetime
import requests
import json

now = datetime.datetime.now()


def cmd(api, message, args, owner_id):
    online = []
    site = 'https://xn--7--6kcajpc3answvrgdm9s.xn----7sb3aecmcv8d.xn--p1ai/api/guest/week-schedule?eclass=9'
    html = requests.get(site)
    htmlLoad = str(html.text)
    data = json.loads(htmlLoad)
    for i in range(0, 100):
        try:
            dataName = data[i]["tasks"][0]["name"]
            dataLeason = data[i]["leason"]["name"]
            dataDay = data[i]["day"]
            dataTimeStart = data[i]["time_start"]
            dataTimeEnd = data[i]["time_end"]
            dataAll = [dataName, dataLeason, dataDay,
                       dataTimeStart, dataTimeEnd]
            d = [dataAll[0], dataAll[1], str(
                dataAll[2]), str(dataAll[3]), str(dataAll[4])]
            now = datetime.datetime.now()
            currentMinute = str(now).split(" ")[0].split("-")[2]
            print(currentMinute)
            if dataAll[2] == int(currentMinute) and dataAll[0].find("Онлайн") != -1:
                online.append(d)

        except IndexError:
            print("")
    if not online:
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message="Онлайн уроков сегодня нет."
        )
    else:
        for l in online:
            f = open('online.txt', 'a', encoding='utf-8')
            f.write(
                "\n " + f'▔▔▔▔▔▔▔▔▔▔▔▔ \n Урок: {l[1]}: {l[0]} \n Дата: {l[2]} Апреля \n Начало урока: {l[3]} \n Конец урока: {l[4]} ')

    try:
        f = open('online.txt', 'r', encoding='utf-8')
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f.read()
        )
        open('online.txt', 'w').close()
    except Exception as e:
        print("Online", e)

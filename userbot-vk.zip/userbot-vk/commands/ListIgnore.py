import functions

def cmd(api, message):
    ignored_users = functions.getData('ignore')
    names = []
    for i in ignored_users:
        users = api.users.get(user_ids=i)
        names.append(f"[id{users[0]['id']}|{users[0]['first_name']} {users[0]['last_name']}]\n")

    api.messages.send(
        peer_id=message['peer_id'],
        random_id=0,
        message=f"Cписок людей в игнор листе:\n {''.join(names)}"
    )


import time
import config
import functions
import random

def cmd(api, message, args, owner_id):
    vka = api.messages.getConversationMembers(peer_id=message['peer_id'])['profiles']
    vka1 = api.messages.getConversationMembers(peer_id=message['peer_id'])['profiles']
    random_id1 = random.choice(vka)["id"]
    random_id2 = random.choice(vka1)["id"]
    name1 = api.users.get(user_id=random_id1)[0]["first_name"]
    name2 = api.users.get(user_id=random_id2)[0]["first_name"]
    first1 = api.users.get(user_id=random_id1)[0]["last_name"]
    first2 = api.users.get(user_id=random_id2)[0]["last_name"]
    rand = random.randint(1,3)
    if rand == 1:
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"💞 РАНДОМ ШИППЕРИМ: @id{random_id1}({name1} {first1}) + @id{random_id2}({name2} {first2}).Любите друг друга и берегите. Мур.)",
            disable_mentions=True
        )
    if rand == 2:
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"💞 РАНДОМ ШИППЕРИМ: @id{603032012}(Рушана Ермакова) + @id{576167340}(Дмитрий Катанов).Любите друг друга и берегите. Мур.)",
            disable_mentions=True
        )
    if rand == 3:
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"💞 РАНДОМ ШИППЕРИМ: @id{603032012}(Рушана Ермакова) + @id{576167340}(Дмитрий Катанов).Любите друг друга и берегите. Мур.)",
            disable_mentions=True
        )
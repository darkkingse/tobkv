import config
import functions
from bs4 import BeautifulSoup
import requests
import datetime
from collections import Counter

def getCitiesUser(api, id):
    cities = []
    cities_two = {}
    sorted_cities = {}
    cities_final = []
    try:
        city_user = api.friends.get(user_id=id, fields="city")
    except:
        return f"{config.prefixes['error']} Произошла ошибка, возможно у пользователя закрыт профиль."
    for i in range(0, city_user['count']+1):
        try:
            cities.append(city_user['items'][i]['city']['title'])
        except:
            continue
    try:
        result = {i: cities.count(i) for i in cities};
        for i in result:
            cities_two[i] = result[i]
    except:
        return f"{config.prefixes['error']} Произошла ошибка, возможно у пользователя закрыт профиль."
    try:
        sorted_keys = sorted(cities_two, key=cities_two.get)  # [1, 3, 2]
        for w in sorted_keys:
            sorted_cities[w] = cities_two[w]
    except:
        print("error 7777")
    try:
        for g in sorted_cities:
            cities_final.append(f"{g}: {sorted_cities[g]}")
    except Exception as e:
        print(e)
    return cities_final

def getDateRegistration(id):
    response = requests.get(f'https://vk.com/foaf.php?id={id}')
    xml = response.text
    soup = BeautifulSoup(xml, 'lxml')
    created = soup.find('ya:created').get('dc:date')
    return created

def cmd(api, message, event, args, owner_id):
    user_id = functions.getUserId(args[1])
    try:
        last_seen_time = api.users.get(user_ids=user_id, fields="last_seen")[0]["last_seen"]["time"]
        last_seen = datetime.datetime.utcfromtimestamp(last_seen_time).strftime(
                        '%Y-%m-%d %H:%M:%S')
    except:
        last_seen = "Онлайн не показан."
    try:
        try:
            if(getCitiesUser(api,user_id).find("❗") == 0):
                msg = f"""
                🔗 Информация о пользователе: {args[1]}
                
                🆔 Идентификатор: {user_id}
                📅 Дата создания страницы: {getDateRegistration(user_id)}
                ⏱ Последний вход: {last_seen}
                📞 Номер телефона: привязан.
                
                🌃 Возможные города: {config.prefixes['error']} Произошла ошибка, возможно у пользователя закрыт профиль.
    
            """.replace('    ', '')
        except:
                msg = f"""
                    🔗 Информация о пользователе: {args[1]}
                    
                    🆔 Идентификатор: {user_id}
                    📅 Дата создания страницы: {getDateRegistration(user_id)}
                    ⏱ Последний вход: {last_seen}
                    📞 Номер телефона: привязан.
                    
                    🌃 Возможные города:
                       {getCitiesUser(api, user_id)[-1]}
                       {getCitiesUser(api, user_id)[-2]}
                       {getCitiesUser(api, user_id)[-3]}
                       {getCitiesUser(api, user_id)[-4]}

                """.replace('    ', '')

        if message['from_id'] == owner_id:
            api.messages.send(
                peer_id=message['peer_id'],
                random_id=0,
                message=msg,
                disable_mentions=True
            )
        else:
            api.messages.send(
                peer_id=message['peer_id'],
                random_id=0,
                message=msg,
                disable_mentions=True
            )

    except Exception as e:
        print(e)
import config
import functions
from bs4 import BeautifulSoup
import requests
import datetime
from collections import Counter

def getCitiesUser(api, id):
    cities = []
    cities_two = []
    try:
        city_user = api.friends.get(user_id=id, fields="city")
    except:
        return "профиль закрыт!"
    for i in range(0, city_user['count']+1):
        try:
            cities.append(city_user['items'][i]['city']['title'])
        except:
            continue
    try:
        result = {i: cities.count(i) for i in cities};
        for i in result:
            cities_two.append(f"{i}: {result[i]}")
    except:
        return f"{config.prefixes['error']} Произошла ошибка, возможно у пользователя закрыт профиль."

    return cities_two

def getDateRegistration(id):
    response = requests.get(f'https://vk.com/foaf.php?id={id}')
    xml = response.text
    soup = BeautifulSoup(xml, 'lxml')
    created = soup.find('ya:created').get('dc:date')
    return created

def cmd(api, message, event, args, owner_id):
    cities = []
    out_message = ''
    user_id = functions.getUserId(args[1])
    last_seen_time = api.users.get(user_ids=user_id, fields="last_seen")[0]["last_seen"]["time"]
    last_seen = datetime.datetime.utcfromtimestamp(last_seen_time).strftime(
                    '%Y-%m-%d %H:%M:%S')
    print(getCitiesUser(api, user_id))
    try:
        msg = f"""
            🔗 Информация о пользователе: {args[1]}
            
            🆔 Идентификатор: {user_id}
            📅 Дата создания страницы: {getDateRegistration(user_id)}
            ⏱ Последний вход: {last_seen}
            📞 Номер телефона: привязан.
            
            🌃 Возможные города:
               {getCitiesUser(api, user_id)[0]}
               {getCitiesUser(api, user_id)[1]}
               {getCitiesUser(api, user_id)[2]}
               {getCitiesUser(api, user_id)[3]}
        """.replace('    ', '')
        if message['from_id'] == owner_id:
            api.messages.send(
                peer_id=message['peer_id'],
                random_id=0,
                message=msg,
                disable_mentions=True
            )
        else:
            api.messages.send(
                peer_id=message['peer_id'],
                random_id=0,
                message=msg,
                disable_mentions=True
            )

    except Exception as e:
        print(e)
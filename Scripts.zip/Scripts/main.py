 # -*- coding: utf8 -*- 
 #Создатель - chmotie (Сергей Малахов)
 #Во вопросам пиши в личку)
#  ___              _          _        
# / __|  __   _ _  (_)  _ __  | |_   ___
# \__ \ / _| | '_| | | | '_ \ |  _| (_-<
# |___/ \__| |_|   |_| | .__/  \__| /__/
#                      |_|              
#Version:1.0 
#P.S Если ты читаешь,знай, что обнов уже не будет. Идей для обновлений нету.
import vk_api
import colorama
import init
import os
import socket
from sys import platform
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
from vk_api.keyboard import VkKeyboard, VkKeyboardColor
import random
import requests
import time
import datetime
import urllib.request
from vk_api import audio
from vk_api import VkUpload
from rich.console import Console
from bs4 import BeautifulSoup
import threading
import dos
import base64
from python_rucaptcha import ImageCaptcha, RuCaptchaControl, CallbackClient

console = Console()
colorama.init()



def check_os():
    if platform == "linux" or platform == "linux2":
        os.system("clear")
    elif platform == "win32":
       os.system("cls")

raid_bot = ['''
  ___          _      _   ___         _   
 | _ \  __ _  (_)  __| | | _ )  ___  | |_ 
 |   / / _` | | | / _` | | _ \ / _ \ |  _|
 |_|_\ \__,_| |_| \__,_| |___/ \___/  \__|
                                                       
''']

scan_port = ['''
  \033[31m
  ___                      ___               _   
 / __|  __   __ _   _ _   | _ \  ___   _ _  | |_ 
 \__ \ / _| / _` | | ' \  |  _/ / _ \ | '_| |  _|
 |___/ \__| \__,_| |_||_| |_|   \___/ |_|    \__| 
              \033[33mЕсли поставить port "auto" 
              Он сам просканирует популярные порты.                                   
             
''']



hello = [
'''
\033[31m
  ___              _          _        
 / __|  __   _ _  (_)  _ __  | |_   ___
 \__ \ / _| | '_| | | | '_ \ |  _| (_-<
 |___/ \__| |_|   |_| | .__/  \__| /__/
                      |_|                     
            author:chmotie
            version:0.1                                  
'''
]

vktool = ['''
 __   __  _     _____               _      
 \ \ / / | |__ |_   _|  ___   ___  | |  ___
  \ V /  | / /   | |   / _ \ / _ \ | | (_-<
   \_/   |_\_\   |_|   \___/ \___/ |_| /__/
                                           
                                                    
''']

damp = ['''
┌─────────────────────────────────────────────┐
│[1] - Скачать все диалоги                    │
│[2] - Скачать диалог с определенным человеком│ 
└─────────────────────────────────────────────┘    
      ''']
damp_ph = ['''
┌───────────────────────────────────────────────┐
│[1] - Скачать вложения с определенным человеком│
│[2] - Скачать все вложения с профиля           │
└───────────────────────────────────────────────┘
''']

deanon = ['''
  ___                                   
 |   \   ___   __ _   _ _    ___   _ _  
 | |) | / -_) / _` | | ' \  / _ \ | ' \ 
 |___/  \___| \__,_| |_||_| \___/ |_||_|
                                                  
''']
vktool_func = ['''
┌─────────────────────────────────────────────────┐
│[1] - Накрутка смс                               │
│[2] - Накрутка фотографий                        │
│[3] - Накрутка коментов                          │
│[4] - Накрутка постов                            │
│[5] - Скачивание переписок в TXT                 │
│[6] - Скачивание фотографи с профиля человека    │
│[7] - Скачивание музыки                          │
│[8] - Удаление всех ваших друзей                 │
│[9] - Парсер стикеров                            │
│[10] - Авто-статус                               │
│[11] - Бан страницы                              │
│[11] - Накрутка комментарий на фотку             │
│[99] - Выход                                     │
└─────────────────────────────────────────────────┘
''']
menu_nakrutka = ['''
┌──────────────────────────────────────┐
│[1] - Обычная накрутка                │
│[2] - Многопоточная накрутка          │
│[3] - Накрутка с анти-капчей накрутка │         
└──────────────────────────────────────┘

''']
comments = ['''
┌─────────────────────────────────────┐
│[1] - Прочитать все токены           │
│[2] - Добавить токен                 │
│[3] - Начать на фотографию           │
│[4] - Начать накрутку                │
│[4] - Накрутка с анти-капчей накрутка│
└─────────────────────────────────────┘

''']

photik = ['''
┌─────────────────────────────┐
│[1] - Прочитать все токены   │
│[2] - Добавить токен         │
│[3] - Добавить альбом        │
│[4] - Начать накрутку        │
└─────────────────────────────┘

''']

deanon_func = ['''
┌────────────────────┐
│[1] - Пробив IP     │
│[2] - Пробив Номера │        
└────────────────────┘      
''']

#[+] ► 

scripts = ["""\033[31m
            ┌─────────────────┐
            │[1] - Scan Port  │ 
            │[2] - Raid Bot VK│
            │[3] - Deanon     │
            │[4] - VkTools    │
            │[5] - DDOS       │
            │[6] - Sms-Bomber │
            │[7] - Разное     │
            └─────────────────┘                  
           """] 
othering = ["""
  ______   .___________. __    __   _______ .______      
 /  __  \  |           ||  |  |  | |   ____||   _  \     
|  |  |  | `---|  |----`|  |__|  | |  |__   |  |_)  |    
|  |  |  |     |  |     |   __   | |   __|  |      /     
|  `--'  |     |  |     |  |  |  | |  |____ |  |\  \----.
 \______/      |__|     |__|  |__| |_______|| _| `._____|
 \033[32m
                ┌───────────────────────────┐
                │[1] - Парсер прокси №1     │ 
                │[2] - Парсер прокси №2     │
                │[3] - Красивые шрифты      │
                │[4] - ЗакодироватьBase64   │
                │[5] - Раскодировать base64 │
                └───────────────────────────┘             
 \033[31m                       
"""]

list_proxy = ["""
\033[31m
                ┌──────────────────────┐
                │[1] - SOCKS5          │ 
                │[2] - SOCKS4          │
                │[3] - HTTP(S)         │
                └──────────────────────┘  
\033[31m
"""]
def captcha_handler(captcha):
    key = ImageCaptcha.ImageCaptcha(rucaptcha_key="039e2b53fc55ce2f5fc57535bf7c6f7a",
                                    save_format='const').captcha_handler(captcha_link=captcha.get_url())

    print(key)
    return captcha.try_again(key['captchaSolve'])

def html(urls):
    r = requests.get(urls)
    return r.text

def get_html(html):
    soup = BeautifulSoup(html, 'lxml')
    test = soup.find('table',id='theProxyList').find('tbody').find_all('tr')

    for i in test:
        derik = i.find_all('td')
        ip = derik[1].text
        port = derik[2].text

        slovar = {
        'ip':ip,
        'port':port
        }
        
        print(slovar)
        
        print(ip)

def porting():
    check_os()
    print(scan_port[0])
    
    ip = input("\033[31mIP [+] ► ")
    port = input("PORT [+] ► ")
    
    sock = socket.socket()

    try:
        ports = [21, 22, 43, 80, 443, 8000, 8080]
        if port == "auto":
            for i in ports:
                try:
                    sock.connect(((ip,i)))
                except socket.error:
                    console.log(f"[bold red]\033[31m\n[!]ПОРТ ЗАКРЫТ " + str(i))
                else:
                    console.log(f"[bold red]\033[32m\n[!]ПОРТ ОТКРЫТ " + str(i))                    

        else:
            sock.connect(((ip,int(port))))
    except socket.error:

        console.log(f"[bold red]\033[31m\n[!]ПОРТ ЗАКРЫТ " + str(port))
    else:
        console.log(f"[bold red]\033[32m\n[!]ПОРТ ОТКРЫТ " + str(port))
def raidbot():    
    check_os()
    print(raid_bot[0])
    
    token = input("Token [+] ►  ") 
    idgroup = input("ID Group [+] ►  ")
    
    vk_session = vk_api.VkApi(token=token)
    vk = vk_session.get_api()  
    longpoll = VkBotLongPoll(vk_session, idgroup)
    textraid = """🤧😲🤢😳😷😂❤💋😚😕😯😦😵🙄🤔😠😡😝😴😘😗😙😟🙁☹😬😶🤐😫☺😀😥😛😖😤😣😧😑😅😮😞😓😱🤓🤑😪🤒
    🤕🤥🤠😈👿👽👻😸😹😼😽😾😿😻🙀😺🙈🙉🙊💩💀👹👺👍👎☝✌👌🖕🏻🤘🏻👏👊💪✋🖐🏻🖖🏻🙏🙌✊👆👇👈👉👋👐🤞🏻🤝🤙🏻🤛🏻🤜🏻👀👂👃✍🏻👅👫👬👭💏💑👯👪👰👦👧👨👩👱👮👲👳💂👴👵👶👷👸👼🙇🤰🏻💅💄👄💃🎎🎅🚶👱‍♀️👮‍♀️👷‍♀️🕵‍♀️🙇‍♀️🙋‍♂️🙋💁‍♂️💁🙅‍♂️🙅🙆‍♂️🙆🙎‍♂️🙎💆‍♂️💆💇‍♂️💇🤷🏻‍♂️🤷🏻‍♀️🤦🏻‍♂️🤦‍♀️🙍‍♂️🚶‍♀️🤳🏻🏃‍♀️👯‍♂️🏌‍♀️🐱🤡🕺👳‍♀️💂‍♀️🤵🤴🤹‍♂️🤹‍♀️👨‍⚖️👩‍⚖️👨‍✈️👩‍✈️👨‍🚒️👩‍🚒️👨‍🎤️👩‍🎤️👨‍🎓️👩‍🎓️👨‍🏫️👩‍🏫️👨‍🌾️👩‍🌾️👨‍🍳️👩‍🍳️👨‍🔧️👩‍🔧️👨‍🏭️👩‍🏭️👨‍💼️👩‍💼️👨‍🔬️👩‍🔬️👨‍💻️👩‍💻️👨‍🎨️👩‍🎨️👨‍🚀️👩‍🚀️👨‍⚕️👩‍⚕️💓💔💕💖💗💘💙💚💛💜💝💞💟💬💭🔞⚠⛔🐩🆘🌚🖤💨🔥☀☁⛄❄⛅✨🌍🌛🌝🌞☄🌈🌖⚕🌱🌲🌳🌴🌷🌸🍅🍆🍇🍈🍉🍊🍋🍌🍍🍎🍏🍐🍑🐀🐁🐂🐃🐄🐅🐆🐇🐈🐉🐊🐋🐌🐍🐎🐏🐐🐑🐒🐓🐔🐕🐖🐗🐘🐙🐚🐛🐜🐝🐞🐟🐠🐡🐢🐣🐤🐥🐦🐧🐨🐪🐫🐬🐭🐮🐯🐰🐲🐳🐴🐵🐶🐷🐸🐹🐺🐻🐼🐽🐾🌰🌵🌹🌺🌻🌼🌽🌾🌿🍀🍁🍂🍃🍄💦💧🦉🦍🦏🦋🦊🦈🦆🦅🦇🦎🦐🦑🥀🦌🍒🍓🍔🍕🍖🍗🍚🍛🍜🍝🍧🍦🍥🍤🍣🍢🍡🍠🍟🍞🍨🍩🍪🍫🍬🍭🍮🍯🍰🍱🍻🍺🍹🍸🍷🍶🍵🍴🍳🍲🍼🥙🥝🥜🥘🥗🥖🥓🥐🥂🥛🥚🥞🥒🥔🥕🥃🥑⚽⚾🎯🎱🎽🎾🎿🏀🏁🏂🚴🚣👟🏊🏉🏈🏇🏆🏄🏃🚵⛳⛪🤽🏻‍♂️🤽🏻‍♀️🤾🏻‍♂️🤼‍♂️🤸🏻‍♂️🏋‍♀️⛹‍♀️🥅🥋🥊🛶🛴🤺🚴‍♀️🚵‍♀️🏊‍♀️🏄‍♀️🥁🚅🚆🚇🚈🚊🚌🚍🚎🚏🚐🚚🚙🚘🚗🚖🚕🚔🚓🚒🚑🚛🚜🚝🚞🚟🚠🚡🚤🚨🚧🛵🏜✈⛽🚄🚃🚂🚁🚀⛵⏰⏳☎☕♻⚡✂✉✏✒🎈🎄🎃🎂🎁🎀🌟🌂🃏🀄🎉🎊🎋🎌🎍🎏🎐🎒🎓🎣🎲🎰🎭🎬🎫🎪🎩🎨🎧🎤🎳🎴🎷🎸🎹🎺🎻👑👒👓👜👠👛👚👙👘👗👖👕👔👝👞👡👢👣👾💈💉💊💌💴💳💰💥💣💡💒💐💎💍💵💶💷💸💺💻💼💽💾💿📎📍📌📋📊📉📈📇📅📄📐📑📒📓📔📕📖📗📘📙📮📭📦📢📡📠📟📝📜📚📯🔑🔭🥇🥈🔮🔔📰📱🔖🔱🥉🛒🗿🔦📷📹🔧🚪🚬🔨📺📻🔩🚽🚿🔪📼🔆🔫🛀🥄🔬🔎🇨🇳🇺🇦🇮🇱🇳🇿🇫🇮🇮🇷🇹🇳🇲🇦🇨🇱🇳🇴🇮🇳🇰🇿🇩🇪🇪🇸🇧🇾🇮🇩🇦🇪🇨🇭🇳🇬🇵🇦🇸🇪🇵🇱🇮🇪🇦🇺🇫🇷🇬🇧🇦🇹🇨🇦🇵🇹🇿🇦🇵🇪🇷🇸🏳‍🌈️🇵🇷🇨🇴🇧🇪🇮🇹🇯🇵🇧🇷🇲🇴🇸🇦🇦🇷🇸🇳🏴󠁧󠁢󠁥󠁮󠁧󠁿🇨🇷🏴󠁧󠁢󠁥󠁮󠁧󠁿🇨🇷🇸🇬🇲🇾🇻🇳🇰🇷🇷🇺🇭🇰🇲🇽🇹🇷🇪🇬🇺🇾🇮🇸🇭🇷🇵🇭🇳🇱🇩🇰🇩🇰🇺🇸😄😁😊😃🤣😆😉😜😋🤗😍😎😒😏🙂🙃😔😢😭😩😨😐😌🤤😇😰🤧😲🤢😳😷😂❤💋😚😕😯😦😵🙄🤔😠😡😝😴😘😗😙😟🙁☹😬😶🤐😫☺😀😥😛😖😤😣😧😑😅😮😞😓😱🤓🤑😪🤒🤕🤥🤠😈👿👽👻😸😹😼😽😾😿😻🙀😺🙈🙉🙊💩💀👹👺👍👎☝✌👌🖕🏻🤘🏻👏👊💪✋🖐🏻🖖🏻🙏🙌✊👆👇👈👉👋👐🤞🏻🤝🤙🏻🤛🏻🤜🏻👀👂👃✍🏻👅👫👬👭💏💑👯👪👰👦👧👨👩👱👮👲👳💂👴👵👶👷👸👼🙇🤰🏻💅💄👄💃🎎🎅🚶👱‍♀️👮‍♀️👷‍♀️🕵‍♀️🙇‍♀️🙋‍♂️🙋💁‍♂️💁🙅‍♂️🙅🙆‍♂️🙆🙎‍♂️🙎💆‍♂️💆💇‍♂️💇🤷🏻‍♂️🤷🏻‍♀️🤦🏻‍♂️🤦‍♀️🙍‍♂️🚶‍♀️🤳🏻🏃‍♀️👯‍♂️🏌‍♀️🐱🤡🕺👳‍♀️💂‍♀️🤵🤴🤹‍♂️🤹‍♀️👨‍⚖️👩‍⚖️👨‍✈️👩‍✈️👨‍🚒️👩‍🚒️👨‍🎤️👩‍🎤️👨‍🎓️👩‍🎓️👨‍🏫️👩‍🏫️👨‍🌾️👩‍🌾️👨‍🍳️👩‍🍳️👨‍🔧️👩‍🔧️👨‍🏭️👩‍🏭️👨‍💼️👩‍💼️👨‍🔬️👩‍🔬️👨‍💻️👩‍💻️👨‍🎨️👩‍🎨️👨‍🚀️👩‍🚀️👨‍⚕️👩‍⚕️💓💔💕💖💗💘💙💚💛💜💝💞💟💬💭🔞⚠⛔🐩🆘🌚🖤💨🔥☀☁⛄❄⛅✨🌍🌛🌝🌞☄🌈🌖⚕🌱🌲🌳🌴🌷🌸🍅🍆🍇🍈🍉🍊🍋🍌🍍🍎🍏🍐🍑🐀🐁🐂🐃🐄🐅🐆🐇🐈🐉🐊🐋🐌🐍🐎🐏🐐🐑🐒🐓🐔🐕🐖🐗🐘🐙🐚🐛🐜🐝🐞🐟🐠🐡🐢🐣🐤🐥🐦🐧🐨🐪🐫🐬🐭🐮🐯🐰🐲🐳🐴🐵🐶🐷🐸🐹🐺🐻🐼🐽🐾🌰🌵🌹🌺🌻🌼🌽🌾🌿🍀🍁🍂🍃🍄💦💧🦉🦍🦏🦋🦊🦈🦆🦅🦇🦎🦐🦑🥀🦌🍒🍓🍔🍕🍖🍗🍚🍛🍜🍝🍧🍦🍥🍤🍣🍢🍡🍠🍟🍞🍨🍩🍪🍫🍬🍭🍮🍯🍰🍱🍻🍺🍹🍸🍷🍶🍵🍴🍳🍲🍼🥙🥝🥜🥘🥗🥖🥓🥐🥂🥛🥚🥞🥒🥔🥕🥃🥑⚽⚾🎯🎱🎽🎾🎿🏀🏁🏂🚴🚣👟🏊🏉🏈🏇🏆🏄🏃🚵⛳⛪🤽🏻‍♂️🤽🏻‍♀️🤾🏻‍♂️🤼‍♂️🤸🏻‍♂️🏋‍♀️⛹‍♀️🥅🥋🥊🛶🛴🤺🚴‍♀️🚵‍♀️🏊‍♀️🏄‍♀️🥁🚅🚆🚇🚈🚊🚌🚍🚎🚏🚐🚚🚙🚘🚗🚖🚕🚔🚓🚒🚑🚛🚜🚝🚞🚟🚠🚡🚤🚨🚧🛵🏜✈⛽🚄🚃🚂🚁🚀⛵⏰⏳☎☕♻⚡✂✉✏✒🎈🎄🎃🎂🎁🎀🌟🌂🃏🀄🎉🎊🎋🎌🎍🎏🎐🎒🎓🎣🎲🎰🎭🎬🎫🎪🎩🎨🎧🎤🎳🎴🎷🎸🎹🎺🎻👑👒👓👜👠👛👚👙👘👗👖👕👔👝👞КУ ОТ МАЛАХОВА ШАВКИ НАХУЙ ЕБАНЫЕ😆 😆 卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐🤧😲🤢😳😷😂❤💋😚😕😯😦😵🙄🤔😠😡😝😴😘😗😙😟🙁☹😬😶🤐😫☺😀😥😛😖😤😣😧😑😅😮😞😓😱🤓🤑😪🤒🤕🤥🤠😈👿👽👻😸😹😼😽😾😿😻🙀😺🙈🙉🙊💩💀👹👺👍👎☝✌👌🖕🏻🤘🏻👏👊💪✋🖐🏻🖖🏻🙏🙌✊👆👇👈👉👋👐🤞🏻🤝🤙🏻🤛🏻🤜🏻👀👂👃✍🏻👅👫👬👭💏💑👯👪👰👦👧👨👩👱👮👲👳💂👴👵👶👷👸👼🙇🤰🏻💅💄👄💃🎎🎅🚶👱‍♀️👮‍♀️👷‍♀️🕵‍♀️🙇‍♀️🙋‍♂️🙋💁‍♂️💁🙅‍♂️🙅🙆‍♂️🙆🙎‍♂️🙎💆‍♂️💆💇‍♂️💇🤷🏻‍♂️🤷🏻‍♀️🤦🏻‍♂️🤦‍♀️🙍‍♂️🚶‍♀️🤳🏻🏃‍♀️👯‍♂️🏌‍♀️🐱🤡🕺👳‍♀️💂‍♀️🤵🤴🤹‍♂️🤹‍♀️👨‍⚖️👩‍⚖️👨‍✈️👩‍✈️👨‍🚒️👩‍🚒️👨‍🎤️👩‍🎤️👨‍🎓️👩‍🎓️👨‍🏫️👩‍🏫️👨‍🌾️👩‍🌾️👨‍🍳️👩‍🍳️👨‍🔧️👩‍🔧️👨‍🏭️👩‍🏭️👨‍💼️👩‍💼️👨‍🔬️👩‍🔬️👨‍💻️👩‍💻️👨‍🎨️👩‍🎨️👨‍🚀️👩‍🚀️👨‍⚕️👩‍⚕️💓💔💕💖💗💘💙💚💛💜💝💞💟💬💭🔞⚠⛔🐩🆘🌚🖤💨🔥☀☁⛄❄⛅✨🌍🌛🌝🌞☄🌈🌖⚕🌱🌲🌳🌴🌷🌸🍅🍆🍇🍈🍉🍊🍋🍌🍍🍎🍏🍐🍑🐀🐁🐂🐃🐄🐅🐆🐇🐈🐉🐊🐋🐌🐍🐎🐏🐐🐑🐒🐓🐔🐕🐖🐗🐘🐙🐚🐛🐜🐝🐞🐟🐠🐡🐢🐣🐤🐥🐦🐧🐨🐪🐫🐬🐭🐮🐯🐰🐲🐳🐴🐵🐶🐷🐸🐹🐺🐻🐼🐽🐾🌰🌵🌹🌺🌻🌼🌽🌾🌿🍀🍁🍂🍃🍄💦💧🦉🦍🦏🦋🦊🦈🦆🦅🦇🦎🦐🦑🥀🦌🍒🍓🍔🍕🍖🍗🍚🍛🍜🍝🍧🍦🍥🍤🍣🍢🍡🍠🍟🍞🍨🍩🍪🍫🍬🍭🍮🍯🍰🍱🍻🍺🍹🍸🍷🍶🍵🍴🍳🍲🍼🥙🥝🥜🥘🥗🥖🥓🥐🥂🥛🥚🥞🥒🥔🥕🥃🥑⚽⚾🎯🎱🎽🎾🎿🏀🏁🏂🚴🚣👟🏊🏉🏈🏇🏆🏄🏃🚵⛳⛪🤽🏻‍♂️🤽🏻‍♀️🤾🏻‍♂️🤼‍♂️🤸🏻‍♂️🏋‍♀️⛹‍♀️🥅🥋🥊🛶🛴🤺🚴‍♀️🚵‍♀️🏊‍♀️🏄‍♀️🥁🚅🚆🚇🚈🚊🚌🚍🚎🚏🚐🚚🚙🚘🚗🚖🚕🚔🚓🚒🚑🚛🚜🚝🚞🚟🚠🚡🚤🚨🚧🛵🏜✈⛽🚄🚃🚂🚁🚀⛵⏰⏳☎☕♻⚡✂✉✏✒🎈🎄🎃🎂🎁🎀🌟🌂🃏🀄🎉🎊🎋🎌🎍🎏🎐🎒🎓🎣🎲🎰🎭🎬🎫🎪🎩🎨🎧🎤🎳🎴🎷🎸🎹🎺🎻👑👒👓👜👠👛👚👙👘👗👖👕👔👝👞👡👢👣👾💈💉💊💌💴💳💰💥💣💡💒💐💎💍💵💶💷💸💺💻💼💽💾💿📎📍📌📋📊📉📈📇📅📄📐📑📒📓📔📕📖📗📘📙📮📭📦📢📡📠📟📝📜📚📯🔑🔭🥇🥈🔮🔔📰📱🔖🔱🥉🛒🗿🔦📷📹🔧🚪🚬🔨📺📻🔩🚽🚿🔪📼🔆🔫🛀🥄🔬🔎🇨🇳🇺🇦🇮🇱🇳🇿🇫🇮🇮🇷🇹🇳🇲🇦🇨🇱🇳🇴🇮🇳🇰🇿🇩🇪🇪🇸🇧🇾🇮🇩🇦🇪🇨🇭🇳🇬🇵🇦🇸🇪🇵🇱🇮🇪🇦🇺🇫🇷🇬🇧🇦🇹🇨🇦🇵🇹🇿🇦🇵🇪🇷🇸🏳‍🌈️🇵🇷🇨🇴🇧🇪🇮🇹🇯🇵🇧🇷🇲🇴🇸🇦🇦🇷🇸🇳🏴󠁧󠁢󠁥󠁮󠁧󠁿🇨🇷🏴󠁧󠁢󠁥󠁮󠁧󠁿🇨🇷🇸🇬🇲🇾🇻🇳🇰🇷🇷🇺🇭🇰🇲🇽🇹🇷🇪🇬🇺🇾🇮🇸🇭🇷🇵🇭🇳🇱🇩🇰🇩🇰🇺🇸😄😁😊😃🤣😆😉😜😋🤗😍😎😒😏🙂🙃😔😢😭😩😨😐😌🤤😇😰🤧😲🤢😳😷😂❤💋😚😕😯😦😵🙄🤔😠😡😝😴😘😗😙😟🙁☹😬😶🤐😫☺😀😥😛😖😤😣😧😑😅😮😞😓😱🤓🤑😪🤒🤕🤥🤠😈👿👽👻😸😹😼😽😾😿😻🙀😺🙈🙉🙊💩💀👹👺👍👎☝✌👌🖕🏻🤘🏻👏👊💪✋🖐🏻🖖🏻🙏🙌✊👆👇👈👉👋👐🤞🏻🤝🤙🏻🤛🏻🤜🏻👀👂👃✍🏻👅👫👬👭💏💑👯👪👰👦👧👨👩👱👮👲👳💂👴👵👶👷👸👼🙇🤰🏻💅💄👄💃🎎🎅🚶👱‍♀️👮‍♀️👷‍♀️🕵‍♀️🙇‍♀️🙋‍♂️🙋💁‍♂️💁🙅‍♂️🙅🙆‍♂️🙆🙎‍♂️🙎💆‍♂️💆💇‍♂️💇🤷🏻‍♂️🤷🏻‍♀️🤦🏻‍♂️🤦‍♀️🙍‍♂️🚶‍♀️🤳🏻🏃‍♀️👯‍♂️🏌‍♀️🐱🤡🕺👳‍♀️💂‍♀️🤵🤴🤹‍♂️🤹‍♀️👨‍⚖️👩‍⚖️👨‍✈️👩‍✈️👨‍🚒️👩‍🚒️👨‍🎤️👩‍🎤️👨‍🎓️👩‍🎓️👨‍🏫️👩‍🏫️👨‍🌾️👩‍🌾️👨‍🍳️👩‍🍳️👨‍🔧️👩‍🔧️👨‍🏭️👩‍🏭️👨‍💼️👩‍💼️👨‍🔬️👩‍🔬️👨‍💻️👩‍💻️👨‍🎨️👩‍🎨️👨‍🚀️👩‍🚀️👨‍⚕️👩‍⚕️💓💔💕💖💗💘💙💚💛💜💝💞💟💬💭🔞⚠⛔🐩🆘🌚🖤💨🔥☀☁⛄❄⛅✨🌍🌛🌝🌞☄🌈🌖⚕🌱🌲🌳🌴🌷🌸🍅🍆🍇🍈🍉🍊🍋🍌🍍🍎🍏🍐🍑🐀🐁🐂🐃🐄🐅🐆🐇🐈🐉🐊🐋🐌🐍🐎🐏🐐🐑🐒🐓🐔🐕🐖🐗🐘🐙🐚🐛🐜🐝🐞🐟🐠🐡🐢🐣🐤🐥🐦🐧🐨🐪🐫🐬🐭🐮🐯🐰🐲🐳🐴🐵🐶🐷🐸🐹🐺🐻🐼🐽🐾🌰🌵🌹🌺🌻🌼🌽🌾🌿🍀🍁🍂🍃🍄💦💧🦉🦍🦏🦋🦊🦈🦆🦅🦇🦎🦐🦑🥀🦌🍒🍓🍔🍕🍖🍗🍚🍛🍜🍝🍧🍦🍥🍤🍣🍢🍡🍠🍟🍞🍨🍩🍪🍫🍬🍭🍮🍯🍰🍱🍻🍺🍹🍸🍷🍶🍵🍴🍳🍲🍼🥙🥝🥜🥘🥗🥖🥓🥐🥂🥛🥚🥞🥒🥔🥕🥃🥑⚽⚾🎯🎱🎽🎾🎿🏀🏁🏂🚴🚣👟🏊🏉🏈🏇🏆🏄🏃🚵⛳⛪🤽🏻‍♂️🤽🏻‍♀️🤾🏻‍♂️🤼‍♂️🤸🏻‍♂️🏋‍♀️⛹‍♀️🥅🥋🥊🛶🛴🤺🚴‍♀️🚵‍♀️🏊‍♀️🏄‍♀️🥁🚅🚆🚇🚈🚊🚌🚍🚎🚏🚐🚚🚙🚘🚗🚖🚕🚔🚓🚒🚑🚛🚜🚝🚞🚟🚠🚡🚤🚨🚧🛵🏜✈⛽🚄🚃🚂🚁🚀⛵⏰⏳☎☕♻⚡✂✉✏✒🎈🎄🎃🎂🎁🎀🌟🌂🃏🀄🎉🎊🎋🎌🎍🎏🎐🎒🎓🎣🎲🎰🎭🎬🎫🎪🎩🎨🎧🎤🎳🎴🎷🎸🎹🎺🎻👑👒👓👜👠👛👚👙👘👗👖👕👔👝👞КУ ОТ МАЛАХОВА ШАВКИ НАХУЙ ЕБАНЫЕ😆 😆 卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐卐"""
    for event in longpoll.listen():
        if event.type == VkBotEventType.MESSAGE_NEW:
            if event.from_chat:
                while True:
                    colorr = random.choice(['negative','primary', 'positive', 'secondary'])
                    color = random.choice(['negative','positive', 'primary', 'secondary'])
                    colo = random.choice(['negative','primary', 'positive', 'secondary'])
                    col = random.choice(['negative','primary', 'positive', 'secondary'])
                    textfobot = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    textfobo = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    textfob = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    textfo = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    keyboard = VkKeyboard(one_time=False)
                    keyboard.add_button(textfobot, color=colorr)
                    keyboard.add_button(textfobo, color=color)
                    keyboard.add_button(textfob, color=colo)
                    keyboard.add_button(textfo, color=col)
                    keyboard.add_line()
                    text1 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text2 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text3 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text4 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    col1 = random.choice(['negative','primary', 'positive', 'secondary'])
                    col2 = random.choice(['negative','primary', 'positive', 'secondary'])
                    col3 = random.choice(['negative','primary', 'positive', 'secondary'])
                    col4 = random.choice(['negative','primary', 'positive', 'secondary'])
                    keyboard.add_button(text1, color=col1)
                    keyboard.add_button(text2, color=col2)
                    keyboard.add_button(text3, color=col3)
                    keyboard.add_button(text4, color=col4)
                    keyboard.add_line()
                    text1 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text2 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text3 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text4 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    col1 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col2 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col3 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col4 = random.choice(['negative', 'positive', 'secondary', 'primary'])
                    keyboard.add_button(text1,color=col1)
                    keyboard.add_button(text2,color=col2)
                    keyboard.add_button(text3,color=col3)
                    keyboard.add_button(text4,color=col4)
                    keyboard.add_line()
                    text1 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text2 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text3 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text4 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    col1 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col2 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col3 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col4 = random.choice(['negative', 'positive', 'secondary', 'primary'])
                    keyboard.add_button(text1, color=col1)
                    keyboard.add_button(text2, color=col2)
                    keyboard.add_button(text3, color=col3)
                    keyboard.add_button(text4, color=col4)
                    keyboard.add_line()
                    text1 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text2 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text3 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text4 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    col1 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col2 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col3 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col4 = random.choice(['negative', 'positive', 'secondary', 'primary'])
                    keyboard.add_button(text1, color=col1)
                    keyboard.add_button(text2, color=col2)
                    keyboard.add_button(text3, color=col3)
                    keyboard.add_button(text4, color=col4)
                    keyboard.add_line()
                    text1 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text2 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text3 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text4 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    col1 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col2 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col3 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col4 = random.choice(['negative', 'positive', 'secondary', 'primary'])
                    keyboard.add_button(text1, color=col1)
                    keyboard.add_button(text2, color=col2)
                    keyboard.add_button(text3, color=col3)
                    keyboard.add_button(text4, color=col4)
                    keyboard.add_line()
                    text1 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru'])
                    text2 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text3 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text4 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    col1 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col2 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col3 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col4 = random.choice(['negative', 'positive', 'secondary', 'primary'])
                    keyboard.add_button(text1, color=col1)
                    keyboard.add_button(text2, color=col2)
                    keyboard.add_button(text3, color=col3)
                    keyboard.add_button(text4, color=col4)
                    keyboard.add_line()
                    text1 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text2 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text3 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text4 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    col1 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col2 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col3 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col4 = random.choice(['negative', 'positive', 'secondary', 'primary'])
                    keyboard.add_button(text1, color=col1)
                    keyboard.add_button(text2, color=col2)
                    keyboard.add_button(text3, color=col3)
                    keyboard.add_button(text4, color=col4)
                    keyboard.add_line()
                    text1 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text2 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text3 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text4 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    col1 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col2 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col3 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col4 = random.choice(['negative', 'positive', 'secondary', 'primary'])
                    keyboard.add_button(text1, color=col1)
                    keyboard.add_button(text2, color=col2)
                    keyboard.add_button(text3, color=col3)
                    keyboard.add_button(text4, color=col4)
                    keyboard.add_line()
                    text1 = random.choice(['[СТОП|sosi.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text2 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text3 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    text4 = random.choice(['[СТОП|vto.pe]', '[STOP|olike.ru]', '[СТОП|vkrutilka.ru]'])
                    col1 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col2 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col3 = random.choice(['negative', 'primary', 'positive', 'secondary'])
                    col4 = random.choice(['negative', 'positive', 'secondary', 'primary'])
                    keyboard.add_button(text1, color=col1)
                    keyboard.add_button(text2, color=col2)
                    keyboard.add_button(text3, color=col3)
                    keyboard.add_button(text4, color=col4)
                    vk.messages.send(chat_id=event.chat_id,message=textraid,random_id='0',keyboard=keyboard.get_keyboard(),v=5.95)
                    vk.messages.send(chat_id=event.chat_id,message=textraid,random_id='0',keyboard=keyboard.get_keyboard(),v=5.95)
                    console.log(f"[bold red]Raid Пошел!")
    
def deanons():
    check_os()
    print(deanon[0] + deanon_func[0])
    
    vibord = input("[+] ►  ")
    if vibord  == '1':
        ip = input("IP [+] ►  ")
        rs = requests.get("http://ip-api.com/json/" + ip)
        gan = rs.json()
        country = gan['country']
        code = gan['countryCode']
        reg = gan['region']
        regn = gan['regionName']
        cit = gan['city']
        prova = gan['isp']
        organiz = gan['org']
        quer = gan['query']
        sta = gan['status']
        print(f'❗IP: {quer} \nСтатус: {sta} \nСтрана: {country} \nКод: {code} \nНазвание региона: {regn} \nГород: {cit} \nПровайдер: {prova} \nОрганизация: {organiz}') 
            
    if vibord == '2':   
        num = input("Number [+] ►  ") 
        num = num.replace('-','')
        num = num.replace('+','')
        num = num.replace(' ','')
        resw = requests.get(f"https://htmlweb.ru/geo/api.php?json&telcod={num}")
        js = resw.json()
        reg = js['region']['name']
        quer = js['capital']['name']
        oper = js['0']['oper']
        print('Поиск информации... ')
        time.sleep(3)
        print(f'Номер телефона: {num} \nРегион: {reg} \nОператор: {oper} \nГород: {quer}')
    
    else:
        console.log(f"[bold red][!] Ошибка.")

def vktools():
    check_os()
    print(vktool[0] + vktool_func[0])
    
    vibortool = input("[+] ►  ")
    
    if vibortool == "1":

        token = input("Token [+] ►  ")
        kolvo = input("Кол-во SMS [+] ►  ")
        peoples = input("ID Людей которые будут в накрутке [+] ►  ")
        
        vk_session = vk_api.VkApi(token=token)
        vk = vk_session.get_api()
        
        i = 0
        try:
            while i < int(kolvo):
                vk.messages.createChat(user_ids=peoples,title='Накрутка228')
                i += 1
                time.sleep(60)
            i = 0
        except vk_api.exceptions.ApiError:
            console.log(f"[bold red][!] Проверьте токен и ID Пользователей.")
        
    if vibortool == "2":
        
        check_os()
        print(vktool[0] + photik[0])
        viborcomms = input("[+] ►  ")
        if viborcomms == "1":
            token_file = open("VkFiles/token.txt", "r", encoding="utf-8")
            token_read = token_file.readlines()
            console.log(f"[bold red]Найдено: " + str(len(token_read)) + " Токенов(Токена)")
        elif viborcomms == "2":
            token = input("Token который необходимо добавить [+] ►  ")
            token_file = open("VkFiles/token.txt", "a", encoding="utf-8")
            token_file.write(str(token) + '\n')
        elif viborcomms == "3":
            album_ids = input("AlbumId [+] ► ")
            album_file = open("VkFiles/album.txt", "a", encoding="utf-8")
            album_file.write(str(album_ids) + '\n')
        elif viborcomms == "4":
            print(vktool[0] + menu_nakrutka[0])
            nakvib = input("[+] ►  ")
            if nakvib == "1":
                    
                token = open("VkFiles/token.txt","r",encoding="utf-8")
                tokens = token.readlines()
                token_r = [i.rstrip() for i in tokens]

                alb = open("VkFiles/album.txt","r",encoding="utf-8")
                album = alb.readlines()
                album_r = [i.rstrip() for i in album]

                i = 0
                try:
                    while True: 
                        while i < len(token_r):
                            vk_session = vk_api.VkApi(token=token_r[i])
                            vks = vk_session        
                            upload = VkUpload(vk_session)
                            upload.photo(photos="photo.jpg",album_id=album_r[i])
                            console.log(f"[bold red] Накрутка фотографий пошла...")
                            i+=1
                        i = 0
                except FileNotFoundError:
                    console.log(f"[bold red]У вас нету файла фотки.\n Загрузите его, скиньте фотографию в папку VkFiles.\n Обязательно что бы она была под названием 'photo.jpg' ")
            if nakvib == "2":
                b = int(input("Кол-во потоков [+] ► "))
                def mnogopot():
                    token = open("VkFiles/token.txt","r",encoding="utf-8")
                    tokens = token.readlines()
                    token_r = [i.rstrip() for i in tokens]

                    alb = open("VkFiles/album.txt","r",encoding="utf-8")
                    album = alb.readlines()
                    album_r = [i.rstrip() for i in album]

                    i = 0
                    b = 0
                    try:
                        while 1: 
                            while i < len(token_r):
                                vk_session = vk_api.VkApi(token=token_r[i])
                                vks = vk_session        
                                upload = VkUpload(vk_session)
                                upload.photo(photos="photo.jpg",album_id=album_r[i])
                                console.log(f"[bold red] Накрутка фотографий пошла...")
                                b+=1
                                i+=1
                            i = 0
                    except FileNotFoundError:
                        console.log(f"[bold red]Здравствуйте, у вас нету файла фотки.\n Загрузите его, скиньте фотографию в папку со скриптом.\n Обязательно что бы она была под названием 'photo.jpg' ")
                for i in range(b):
                    t = threading.Thread(target=mnogopot)
                    t.start()
            if nakvib == "3":

                token = open("VkFiles/token.txt", "r", encoding="utf-8")
                tokens = token.readlines()
                token_r = [i.rstrip() for i in tokens]

                alb = open("VkFiles/album.txt", "r", encoding="utf-8")
                album = alb.readlines()
                album_r = [i.rstrip() for i in album]

                captcha_tok = input("TokenCaptcha [+] ► ")

                i = 0
                try:
                    while True:
                        while i < len(token_r):
                            vk_session = vk_api.VkApi(token=token_r[i],captcha_handler=captcha_handler)
                            vks = vk_session
                            upload = VkUpload(vk_session)
                            upload.photo(photos="photo.jpg", album_id=album_r[i])
                            console.log(f"[bold red] Накрутка фотографий пошла...")
                            i += 1
                        i = 0
                except Exception as e:
                    print(e)
            
    if vibortool == "3":
        check_os()
        print(vktool[0] + comments[0])
        viborcomm = input("[+] ►  ")
        if viborcomm == "1":
            token_file = open("VkFiles/token.txt","r",encoding="utf-8")
            token_read = token_file.readlines()
            console.log(f"[bold red]Найдено: " + str(len(token_read)) + " Токенов(Токена)")
        elif viborcomm == "2":
            token = input("Token который необходимо добавить [+] ►  ")
            token_file = open("token.txt","a",encoding="utf-8")
            token_file.write(str(token) + '\n')
            
            console.log(f"[bold red]Вы добавили токен!")
        elif viborcomm == "3":
            owner_id = input("Id Профиля [+] ►  ")
            post_id = input("Post Id [+] ►  ")
            message = input("Текст коммента [+] ►  ")
            zaderjska = input("Задержка [+] ►  ")
            token = open("VkFiles/token.txt","r",encoding="utf-8")
            tokens = token.readlines()
            token_r = [i.rstrip() for i in tokens]

            i = 0 
            while True:
                while i < len(token_r):
                    vk_session = vk_api.VkApi(token=token_r[i])
                    vk = vk_session.get_api()
                    vk.wall.createComment(owner_id=owner_id, post_id=post_id, message=message)
                    console.log(f"[bold red]Накрутка запущена.")
                    time.sleep(int(zaderjska))
                    i += 1
                i = 0
        elif viborcomm == "4":
            owner_id = input("Id Профиля [+] ►  ")
            post_id = input("Post Id [+] ►  ")
            message = input("Текст коммента [+] ►  ")
            zaderjska = input("Задержка [+] ►  ")
            token = open("VkFiles/token.txt","r",encoding="utf-8")
            tokens = token.readlines()
            token_r = [i.rstrip() for i in tokens]

            i = 0 
            while True:
                while i < len(token_r):
                    vk_session = vk_api.VkApi(token=token_r[i])
                    vk = vk_session.get_api()
                    vk.wall.createComment(owner_id=owner_id, post_id=post_id, message=message)
                    console.log(f"[bold red]Накрутка запущена.")
                    time.sleep(int(zaderjska))
                    i += 1
                i = 0

        elif viborcomm == "4":
            owner_id = input("Id Профиля [+] ►  ")
            post_id = input("Post Id [+] ►  ")
            message = input("Текст коммента [+] ►  ")
            zaderjska = input("Задержка [+] ►  ")
            cap = input("TokenCaptcha [+] ► ")
            token = open("VkFiles/token.txt", "r", encoding="utf-8")
            tokens = token.readlines()
            token_r = [i.rstrip() for i in tokens]

            i = 0
            while True:
                while i < len(token_r):
                    vk_session = vk_api.VkApi(token=token_r[i],captcha_handler=captcha_handler)
                    vk = vk_session.get_api()
                    vk.wall.createComment(owner_id=owner_id, post_id=post_id, message=message)
                    console.log(f"[bold red]Накрутка запущена.")
                    time.sleep(int(zaderjska))
                    i += 1
                i = 0
                
    elif vibortool == "4":
        check_os()
        print(vktool[0] + comments[0])
        vibored = input("[+] ►  ")
        if vibored == "1":
            token = open("VkFiles/token.txt", "r", encoding="utf-8")
            token_r = token.readlines()
            console.log(f"[bold red]Найдено: " + str(len(token_r)) + " Токенов(Токена)")
        elif vibored == "2":
            tokens = input("Token -> ")
            token = open("VkFiles/token.txt", "a", encoding="utf-8")
            token.write(str(tokens) + '\n')
        elif vibored == "3":      
            owner_id = input("Id Профиля [+] ►  ")
            message = input("Текст поста [+] ►  ")
            zaderjska = input("Задержка [+] ►  ")
            
            token = open("VkFiles/token.txt", "r", encoding="utf-8")
            tokens = token.readlines()
            token_r = [i.rstrip() for i in tokens]
            i = 0 
            while True:
                while i < len(token_r):
                    
                    vk_session = vk_api.VkApi(token=token_r[i])
                    vk = vk_session.get_api()
                    vk.wall.post(owner_id=owner_id,message=message)
                    time.sleep(int(zaderjska))
                    i += 1
                i = 0
        else:
            console.log(f"[bold red][!] Неверный параметр!")

                
    if vibortool == "5":
        check_os()
        print(vktool[0] + damp[0])
        vibored = input("[+] ►  ")
        if vibored == "1":
            token = input("Token [+] ►  ")
            vk_session = vk_api.VkApi(token=token)
            vk = vk_session.get_api()
            a = vk.friends.get(order='name',count=5000,fields='domain, first_name, last_name')
            
            for i in a["items"]:
                k = i['id']
                firstName = vk.users.get(user_id=k)[0]["first_name"]
                lastName = vk.users.get(user_id=k)[0]["last_name"]
                
                g = vk.messages.getHistory(count=1, user_id=k)
                num_m = g['count']#кол-во сообщений
                newpath = os.path.join(f"Dialogs")
                if not os.path.exists(newpath):
                    os.makedirs(newpath)
                newpath = os.path.join(f"Dialogs/user dialog @id{k}")
                if not os.path.exists(newpath):
                    os.makedirs(newpath)
                if num_m > 0:
                    print(f'Дамп юзера - {firstName} {lastName}')
                    print('Кол-во сообщений:', num_m)
                    f = open(f'Dialogs/user dialog @id{k}/Dialog {firstName} {lastName}.txt', 'w', encoding='utf-8')
                    f.write(f'Диалог с {i["first_name"]} {i["last_name"]} \n')
                    response = vk.messages.getHistoryAttachments(peer_id=k,media_type='photo', count = 200 )
                    for i in range(len(response["items"])):
                        photos = str(response['items'][i]['attachment']['photo']['sizes'][-1]['url'])
                        ranint = random.randint(1, 1000000000000)
                        urllib.request.urlretrieve(photos, "Dialogs" + "/" + f"user dialog @id{k}" + "/" + f"{ranint}.jpg")
                    q = 0                      
                    try:
                        while num_m > q:
                            var = vk.messages.getHistory(offset=q, count=200, user_id=k, rev=1)
                            for a in var['items']: 
                                firstName = vk.users.get(user_id=a["from_id"])[0]["first_name"]
                                lastName = vk.users.get(user_id=a["from_id"])[0]["last_name"]
                                times = datetime.datetime.fromtimestamp(a["date"])
                                f.write(f'От: {firstName} {lastName}\n')
                                f.write(f'Дата: {times.strftime("%d/%m/%Y, %H:%M:%S")}\n')
                                f.write(f'Сообщение: {a["text"]}\n')
                                f.write('\n')
                            q +=200
                            time.sleep(0.3)                               
                        f.close()
                    except:
                        pass
                    
        if vibored == "2":
            token = input("Token [+] ►  ")
            vk_session = vk_api.VkApi(token=token)
            vk = vk_session.get_api()
            k = input("ID Пользователя [+] ►  ")
            
            firstName = vk.users.get(user_id=k)[0]["first_name"]
            lastName = vk.users.get(user_id=k)[0]["first_name"]
            g = vk.messages.getHistory(count=1, user_id=k)
            num_m = g['count']#кол-во сообщений
            newpath = os.path.join(f"Dialogs")
            if not os.path.exists(newpath):
                os.makedirs(newpath)
            newpath = os.path.join(f"Dialogs/user dialog @id{k}")
            if not os.path.exists(newpath):
                os.makedirs(newpath)
            if num_m > 0:
                print(f'Дамп юзера - {firstName} {lastName}')
                print('Кол-во сообщений:', num_m)
                f = open(f'Dialogs/user dialog @id{k}/Dialog {firstName} {lastName}.txt', 'w', encoding='utf-8')
                #f.write(f'Диалог с {i["first_name"]} {i["last_name"]} {firstName} {lastName} \n')
                response = vk.messages.getHistoryAttachments(peer_id=k,media_type='photo', count = 200 )
                for i in range(len(response["items"])):
                    photos = str(response['items'][i]['attachment']['photo']['sizes'][-1]['url'])
                    ranint = random.randint(1, 1000000000000)
                    urllib.request.urlretrieve(photos, "Dialogs" + "/" + f"user dialog @id{k}" + "/" + f"{ranint}.jpg")
                q = 0
                try:
                    while num_m > q:
                        response = vk.messages.getHistoryAttachments(peer_id=k,media_type='photo', count = 200 )
                        var = vk.messages.getHistory(offset=q, count=200, user_id=k, rev=1)
                        for a in var['items']:
                            times = datetime.datetime.fromtimestamp(a["date"])  
                            firstName = vk.users.get(user_id=a["from_id"])[0]["first_name"]
                            lastName = vk.users.get(user_id=a["from_id"])[0]["last_name"]
                            times = datetime.datetime.fromtimestamp(a["date"])
                            console.log(f"[bold red]Cкачивание диалога ")
                            f.write(f'От: {firstName} {lastName}\n')
                            f.write(f'Дата: {times.strftime("%d/%m/%Y, %H:%M:%S")}\n')
                            f.write(f'Сообщение: {a["text"]}\n')
                            f.write('\n')
                            
                        q +=200
                        time.sleep(0.3)
                    f.close()
                except:
                    pass
                            
    elif vibortool == "6":
        check_os()
        print(vktool[0] + damp_ph[0])
        vibored = input("[+] ►  ")
        if vibored == "1":
            token = input("Token [+] ►  ")
            uid = input("ID Пользователя [+] ►  ")
            vk_session = vk_api.VkApi(token=token)
            vk = vk_session.get_api() 
            
            newpath = os.path.join(uid)
            if not os.path.exists(newpath):
                os.makedirs(newpath)
            try:
                responce = vk.photos.get(owner_id=uid,album_id="profile",count=50)
                for i in range(len(responce["items"])):
                    req = str(responce["items"][i]["sizes"][-1]["url"])
                    urllib.request.urlretrieve(req, newpath + '/' + str(responce["items"][i]['id']) + '.jpg')
                    console.log(f"[bold red]\033[33m Скачивание фотографий с профиля " + uid + " Пошла")
            except vk_api.exceptions.ApiError:
                pass
            
        if vibored == "2":
            token = input("Token [+] ►  ")
            vk_session = vk_api.VkApi(token=token)
            vk = vk_session.get_api()
            file_id = open(os.path.join('VkFiles/users_id.txt'), 'w')
            a = vk.friends.get(order='name',count=5000,fields='domain, first_name, last_name')
            for i in a["items"]:
                k = i['id']
                file_id.write(str(k) + '\n')
            
            file_id = open('VkFiles/users_id.txt', 'r')
            data_list = file_id.readlines()
            id_list = []
            for line in data_list:
                id_list.append(line.strip())
                
                
            for id_user in data_list:
                newpath = os.path.join(id_user)
                if not os.path.exists(newpath):
                    os.makedirs(newpath)
            

            try:
                for ie in id_list:
                    try:
                        responce = vk.photos.get(owner_id=ie,album_id="profile",count=50)
                    except:
                        continue
                    
                    for i in range(len(responce["items"])):
                        req = str(responce["items"][i]["sizes"][-1]["url"])
                        urllib.request.urlretrieve(req, newpath + '/' + str(responce["items"][i]['id']) + '.jpg')
                        console.log(f"[bold red]\033[33m Скачивание фотографий с профиля " + ie + " Пошла")
            except vk_api.exceptions.ApiError:
                console.log(f"[bold red]Нету фотографии.")
            
    elif vibortool == "7":
        login = input("Login [+] ►  ")
        passw = input ("Password [+] ►  ")
        uid = input("Ваш ID [+] ►  ")
        REQUEST_STATUS_CODE = 200
        vk_session = vk_api.VkApi(login=login, password=passw)
        vk_session.auth()
        vk = vk_session.get_api() 
        
        newpath = os.path.join("Music")
        if not os.path.exists(newpath):
            os.makedirs(newpath)

        vk_audio = audio.VkAudio(vk_session)
        for i in vk_audio.get(owner_id=uid):
            try:
                r = requests.get(i["url"])
                if r.status_code == REQUEST_STATUS_CODE:
                    artist = i['artist']
                    title = i['title']
                    with open(f"Music/{artist}_{title}.mp3", 'wb') as output_file:
                        output_file.write(r.content)
            except OSError:
                print(i["artist"] + '_' + i["title"])
    elif vibortool == "8":
        token = input("Token -- >")
        vk_session = vk_api.VkApi(token=token)
        vk = vk_session.get_api()
        adds =  vk.friends.get()['items']
        i = 0
        while len(adds) > i: 
            for iw in adds:
                vk.friends.delete(user_id=iw)
                console.log(f"[bold red]\033[33m Удален человек:vk.com/id" + str(iw))
            i += 1
    elif vibortool == "9":
        token = input("Token -- >")
        vk_session = vk_api.VkApi(token=token)
        vk = vk_session.get_api()
        parse = [i for i in range(19415)]
        b = 0
        link = 'https://vk.com/sticker/1'
        
        newpath = os.path.join("Stickers")
        if not os.path.exists(newpath):
            os.makedirs(newpath)
            
        for i in parse:
            print(f'{link}-{i}-128')
            p = requests.get(f'{link}-{i}-128')
            out = open(f'Stickers/{b}.png', "wb")
            out.write(p.content)
            out.close()
            b += 1
    elif vibortool == "10":
        token = input("Token[+] ►")
        vk_session = vk_api.VkApi(token=token)
        vk = vk_session.get_api()

        while True:
            time.sleep(60)
            fuck = datetime.datetime.now()
            times = fuck.strftime("%H:%M")
            times = times.replace("1", "1️⃣")
            times = times.replace("2", "2️⃣")
            times = times.replace("3", "3️⃣")
            times = times.replace("4", "4️⃣")
            times = times.replace("5", "5️⃣")
            times = times.replace("6", "6️⃣")
            times = times.replace("7", "7️⃣")
            times = times.replace("8", "8️⃣")
            times = times.replace("9", "9️⃣")
            times = times.replace("0", "0️⃣")
            dialog = vk.messages.getConversations(offset=0, count=0)["count"]
            onlines = len(vk.friends.getOnline())
            # dialogs = vk.messages.getConversations(offset=0,count=10)["items"][0]["conversation"]["chat_settings"]["title"]
            fuckkk = fuck.strftime("%D")
            fuckkk = fuckkk[3:-3]
            fuckkk = fuckkk.replace("1", "1️⃣")
            fuckkk = fuckkk.replace("2", "2️⃣")
            fuckkk = fuckkk.replace("3", "3️⃣")
            fuckkk = fuckkk.replace("4", "4️⃣")
            fuckkk = fuckkk.replace("5", "5️⃣")
            fuckkk = fuckkk.replace("6", "6️⃣")

            fuckkk = fuckkk.replace("8", "8️⃣")
            fuckkk = fuckkk.replace("9", "9️⃣")
            fuckkk = fuckkk.replace("0", "0️⃣")
            messages = vk.messages.getDialogs(count=1)["items"][0]["message"]["title"]
            getLikes = vk.photos.get(album_id = "profile", rev = "1", extended = "1", count = "1")["items"][0]["likes"]["count"]
            vk.status.set(text=f'• ⌛{times}😀 |Друзей онлайн✔: {onlines} |✉ Диалогов: {dialog} |Day:{fuckkk}😊 | 🍰 Вечный Онлайн 🍰 | ❤Лайков на аве:{getLikes}')
        console.log("Выставил")
    elif vibortool == "11":
        print(vktool[0])
        print("НА СВОЕЙ СТРАНИЦЫ, СКРИПТ НЕ ЗАПУСКАТЬ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        tokens = input("Token[+] ► ")
        token = vk_api.VkApi(token=tokens)
        vk = token.get_api()
        vk.wall.post(message='Malaxov ebet detey shlux')
        for i in range(15):
            try:
                vk.wall.post(message='vto.pe')
                console.log('[bold green]Ожидайте бана!')
                time.sleep(2)
            except Exception as er:
                console.log('[bold green]Аккаунт в бане!')
                main()
    #  elif vibortool == "12":
    #      print(vktool[0])
         

def font():
    eng = u"~!@#$%^&qwertyuiop[]asdfghjkl;'zxcvbnm,./QWERTYUIOP{}ASDFGHJKL:\"|ZXCVBNM<>?"
    rus = u"ё!\"№;%:?йцукенгшщзхъфывапролджэячсмитьбю.ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭ/ЯЧСМИТЬБЮ,"
    fonts = {
        '1': u"~!@#$%^&𝕢𝕨𝕖𝕣𝕥𝕪𝕦𝕚𝕠𝕡[]𝕒𝕤𝕕𝕗𝕘𝕙𝕛𝕜𝕝;'𝕫𝕩𝕔𝕧𝕓𝕟𝕞,./ℚ𝕎𝔼ℝ𝕋𝕐𝕌𝕀𝕆ℙ{}𝔸𝕊𝔻𝔽𝔾ℍ𝕁𝕂𝕃:\"|ℤ𝕏ℂ𝕍𝔹ℕ𝕄<>?",
        '2': u"~!@#$%^&𝚚𝚠𝚎𝚛𝚝𝚢𝚞𝚒𝚘𝚙[]𝚊𝚜𝚍𝚏𝚐𝚑𝚓𝚔𝚕;'𝚣𝚡𝚌𝚟𝚋𝚗𝚖,./𝚀𝚆𝙴𝚁𝚃𝚈𝚄𝙸𝙾𝙿{}𝙰𝚂𝙳𝙵𝙶𝙷𝙹𝙺𝙻:\"|𝚉𝚇𝙲𝚅𝙱𝙽𝙼<>?",
        '3': u"~!@#$%^&𝓆𝓌ℯ𝓇𝓉𝓎𝓊𝒾ℴ𝓅[]𝒶𝓈𝒹𝒻ℊ𝒽𝒿𝓀𝓁;'𝓏𝓍𝒸𝓋𝒷𝓃𝓂,./𝒬𝒲ℰℛ𝒯𝒴𝒰ℐ𝒪𝒫{}𝒜𝒮𝒟ℱ𝒢ℋ𝒥𝒦ℒ:\"|𝒵𝒳𝒞𝒱ℬ𝒩ℳ<>?",
        '4': u"~!@#$%^&𝓺𝔀𝓮𝓻𝓽𝔂𝓾𝓲𝓸𝓹[]𝓪𝓼𝓭𝓯𝓰𝓱𝓳𝓴𝓵;'𝔃𝔁𝓬𝓿𝓫𝓷𝓶,./𝓠𝓦𝓔𝓡𝓣𝓨𝓤𝓘𝓞𝓟{}𝓐𝓢𝓓𝓕𝓖𝓗𝓙𝓚𝓛:\"|𝓩𝓧𝓒𝓥𝓑𝓝𝓜<>?",
        '5': u"~¡@#$%^&bʍǝɹʇʎnᴉod[]ɐspɟƃɥɾʞl;'zxɔʌquɯ,./bʍǝɹʇʎnᴉod{}ɐspɟƃɥɾʞl:\"|zxɔʌquɯ<>¿",
        '6': u"~!@#$%^&ǫᴡᴇʀᴛʏᴜɪᴏᴘ[]ᴀsᴅғɢʜᴊᴋʟ;'ᴢxᴄᴠʙɴᴍ,./QWERTYUIOP{}ASDFGHJKL:\"|ZXCVBNM<>?",
        '7': u"~!@#$%^&ᑫᗯᗴᖇTYᑌIOᑭ[]ᗩՏᗪᖴᘜᕼᒍKᒪ;'ᘔ᙭ᑕᐯᗷᑎᗰ,./ᑫᗯᗴᖇTYᑌIOᑭ{}ᗩՏᗪᖴᘜᕼᒍKᒪ:\"|ᘔ᙭ᑕᐯᗷᑎᗰ<>?",
        '8': u"~!@#$%^&𝐪𝐰𝐞𝐫𝐭𝐲𝐮𝐢𝐨𝐩[]𝐚𝐬𝐝𝐟𝐠𝐡𝐣𝐤𝐥;'𝐳𝐱𝐜𝐯𝐛𝐧𝐦,./𝐐𝐖𝐄𝐑𝐓𝐘𝐔𝐈𝐎𝐏{}𝐀𝐒𝐃𝐅𝐆𝐇𝐉𝐊𝐋:\"|𝐙𝐗𝐂𝐕𝐁𝐍𝐌<>?",
        '9': u"~!@#$%^&𝑞𝑤𝑒𝑟𝑡𝑦𝑢𝑖𝑜𝑝[]𝑎𝑠𝑑𝑓𝑔ℎ𝑗𝑘𝑙;'𝑧𝑥𝑐𝑣𝑏𝑛𝑚,./𝑄𝑊𝐸𝑅𝑇𝑌𝑈𝐼𝑂𝑃{}𝐴𝑆𝐷𝐹𝐺𝐻𝐽𝐾𝐿:\"|𝑍𝑋𝐶𝑉𝐵𝑁𝑀<>?",
        '10': u"~!@#$%^&𝒒𝒘𝒆𝒓𝒕𝒚𝒖𝒊𝒐𝒑[]𝒂𝒔𝒅𝒇𝒈𝒉𝒋𝒌𝒍;'𝒛𝒙𝒄𝒗𝒃𝒏𝒎,./𝑸𝑾𝑬𝑹𝑻𝒀𝑼𝑰𝑶𝑷{}𝑨𝑺𝑫𝑭𝑮𝑯𝑱𝑲𝑳:\"|𝒁𝑿𝑪𝑽𝑩𝑵𝑴<>?",
        '11': u"~!@#$%^&ⓆⓌⒺⓇⓉⓎⓊⒾⓄⓅ[]ⒶⓈⒹⒻⒼⒽⒿⓀⓁ;'ⓏⓍⒸⓋⒷⓃⓂ,./ⓆⓌⒺⓇⓉⓎⓊⒾⓄⓅ{}ⒶⓈⒹⒻⒼⒽⒿⓀⓁ:\"|ⓏⓍⒸⓋⒷⓃⓂ<>?",
        '12': u"~!@#$%^&🅠🅦🅔🅡🅣🅨🅤🅘🅞🅟[]🅐🅢🅓🅕🅖🅗🅙🅚🅛;'🅩🅧🅒🅥🅑🅝🅜,./🅠🅦🅔🅡🅣🅨🅤🅘🅞🅟{}🅐🅢🅓🅕🅖🅗🅙🅚🅛:\"|🅩🅧🅒🅥🅑🅝🅜<>?",
        '13': u"~!@#$%^&🅀🅆🄴🅁🅃🅈🅄🄸🄾🄿[]🄰🅂🄳🄵🄶🄷🄹🄺🄻;'🅉🅇🄲🅅🄱🄽🄼,./🅀🅆🄴🅁🅃🅈🅄🄸🄾🄿{}🄰🅂🄳🄵🄶🄷🄹🄺🄻:\"|🅉🅇🄲🅅🄱🄽🄼<>?",
        '14': u"~!@#$%^&𝔮𝔴𝔢𝔯𝔱𝔶𝔲𝔦𝔬𝔭[]𝔞𝔰𝔡𝔣𝔤𝔥𝔧𝔨𝔩;'𝔷𝔵𝔠𝔳𝔟𝔫𝔪,./𝔔𝔚𝔈ℜ𝔗𝔜𝔘ℑ𝔒𝔓{}𝔄𝔖𝔇𝔉𝔊ℌ𝔍𝔎𝔏:\"|ℨ𝔛ℭ𝔙𝔅𝔑𝔐<>?",
        '15': u"~!@#$%^&𝖖𝖜𝖊𝖗𝖙𝖞𝖚𝖎𝖔𝖕[]𝖆𝖘𝖉𝖋𝖌𝖍𝖏𝖐𝖑;'𝖟𝖝𝖈𝖛𝖇𝖓𝖒,./𝕼𝖂𝕰𝕽𝕿𝖄𝖀𝕴𝕺𝕻{}𝕬𝕾𝕯𝕱𝕲𝕳𝕵𝕶𝕷:\"|𝖅𝖃𝕮𝖁𝕭𝕹𝕸<>?"
        }
        
    translit = u'ё|!|"|№|;|%|:|?|y|ts|u|k|e|n|g|sh|sch|z|kh||f|y|v|a|p|r|o|l|d|zh|e|ya|ch|s|m|i|t||b|yu|.|Y|TS|U|K|E|N|G|SH|SCH|Z|KH||F|Y|B|A|P|R|O|L|D|ZH|E|/|YA|CH|S|M|I|T||B|YU|'
    translit = dict(zip(rus, translit.split('|')))
    fix={'𝔸': '&#38;#120120;', '𝔹': '&#38;#120121;', '𝔻': '&#38;#120123;', '𝔼': '&#38;#120124;', '𝔽': '&#38;#120125;', '𝔾': '&#38;#120126;', '𝕀': '&#38;#120128;', '𝕁': '&#38;#120129;', '𝕂': '&#38;#120130;', '𝕃': '&#38;#120131;', '𝕄': '&#38;#120132;', '𝕆': '&#38;#120134;', '𝕊': '&#38;#120138;', '𝕋': '&#38;#120139;', '𝕌': '&#38;#120140;', '𝕍': '&#38;#120141;', '𝕎': '&#38;#120142;', '𝕏': '&#38;#120143;', '𝕐': '&#38;#120144;', '𝙰': '&#38;#120432;', '𝙱': '&#38;#120433;', '𝙲': '&#38;#120434;', '𝙳': '&#38;#120435;', '𝙴': '&#38;#120436;', '𝙵': '&#38;#120437;', '𝙶': '&#38;#120438;', '𝙷': '&#38;#120439;', '𝙸': '&#38;#120440;', '𝙹': '&#38;#120441;', '𝙺': '&#38;#120442;', '𝙻': '&#38;#120443;', '𝙽': '&#38;#120445;', '𝙾': '&#38;#120446;', '𝙿': '&#38;#120447;', '𝚀': '&#38;#120448;', '𝚁': '&#38;#120449;', '𝚂': '&#38;#120450;', '𝚃': '&#38;#120451;', '𝚄': '&#38;#120452;', '𝚅': '&#38;#120453;', '𝚆': '&#38;#120454;', '𝚇': '&#38;#120455;', '𝚈': '&#38;#120456;', '𝚉': '&#38;#120457;', '𝒜': '&#38;#119964;', '𝒞': '&#38;#119966;', '𝒟': '&#38;#119967;', '𝒢': '&#38;#119970;', '𝒥': '&#38;#119973;', '𝒦': '&#38;#119974;', '𝒩': '&#38;#119977;', '𝒪': '&#38;#119978;', '𝒫': '&#38;#119979;', '𝒬': '&#38;#119980;', '𝒮': '&#38;#119982;', '𝒯': '&#38;#119983;', '𝒰': '&#38;#119984;', '𝒱': '&#38;#119985;', '𝒲': '&#38;#119986;', '𝒳': '&#38;#119987;', '𝒴': '&#38;#119988;', '𝒵': '&#38;#119989;', '𝓐': '&#38;#120016;', '𝓑': '&#38;#120017;', '𝓒': '&#38;#120018;', '𝓓': '&#38;#120019;', '𝓔': '&#38;#120020;', '𝓕': '&#38;#120021;', '𝓖': '&#38;#120022;', '𝓗': '&#38;#120023;', '𝓘': '&#38;#120024;', '𝓙': '&#38;#120025;', '𝓚': '&#38;#120026;', '𝓛': '&#38;#120027;', '𝓜': '&#38;#120028;', '𝓝': '&#38;#120029;', '𝓞': '&#38;#120030;', '𝓟': '&#38;#120031;', '𝓠': '&#38;#120032;', '𝓡': '&#38;#120033;', '𝓢': '&#38;#120034;', '𝓣': '&#38;#120035;', '𝓤': '&#38;#120036;', '𝓥': '&#38;#120037;', '𝓦': '&#38;#120038;', '𝓧': '&#38;#120039;', '𝓨': '&#38;#120040;', '𝓩': '&#38;#120041;', '𝐀': '&#38;#119808;', '𝐁': '&#38;#119809;', '𝐂': '&#38;#119810;', '𝐃': '&#38;#119811;', '𝐄': '&#38;#119812;', '𝐅': '&#38;#119813;', '𝐆': '&#38;#119814;', '𝐇': '&#38;#119815;', '𝐈': '&#38;#119816;', '𝐉': '&#38;#119817;', '𝐊': '&#38;#119818;', '𝐋': '&#38;#119819;', '𝐌': '&#38;#119820;', '𝐍': '&#38;#119821;', '𝐎': '&#38;#119822;', '𝐏': '&#38;#119823;', '𝐐': '&#38;#119824;', '𝐑': '&#38;#119825;', '𝐒': '&#38;#119826;', '𝐓': '&#38;#119827;', '𝐔': '&#38;#119828;', '𝐕': '&#38;#119829;', '𝐖': '&#38;#119830;', '𝐗': '&#38;#119831;', '𝐘': '&#38;#119832;', '𝐙': '&#38;#119833;', '𝐴': '&#38;#119860;', '𝐵': '&#38;#119861;', '𝐶': '&#38;#119862;', '𝐷': '&#38;#119863;', '𝐸': '&#38;#119864;', '𝐹': '&#38;#119865;', '𝐺': '&#38;#119866;', '𝐻': '&#38;#119867;', '𝐼': '&#38;#119868;', '𝐽': '&#38;#119869;', '𝐾': '&#38;#119870;', '𝐿': '&#38;#119871;', '𝑀': '&#38;#119872;', '𝑁': '&#38;#119873;', '𝑂': '&#38;#119874;', '𝑃': '&#38;#119875;', '𝑄': '&#38;#119876;', '𝑅': '&#38;#119877;', '𝑆': '&#38;#119878;', '𝑇': '&#38;#119879;', '𝑈': '&#38;#119880;', '𝑉': '&#38;#119881;', '𝑊': '&#38;#119882;', '𝑋': '&#38;#119883;', '𝑌': '&#38;#119884;', '𝑍': '&#38;#119885;', '𝑨': '&#38;#119912;', '𝑩': '&#38;#119913;', '𝑪': '&#38;#119914;', '𝑫': '&#38;#119915;', '𝑬': '&#38;#119916;', '𝑭': '&#38;#119917;', '𝑮': '&#38;#119918;', '𝑯': '&#38;#119919;', '𝑰': '&#38;#119920;', '𝑱': '&#38;#119921;', '𝑲': '&#38;#119922;', '𝑳': '&#38;#119923;', '𝑴': '&#38;#119924;', '𝑵': '&#38;#119925;', '𝑶': '&#38;#119926;', '𝑷': '&#38;#119927;', '𝑸': '&#38;#119928;', '𝑹': '&#38;#119929;', '𝑺': '&#38;#119930;', '𝑻': '&#38;#119931;', '𝑼': '&#38;#119932;', '𝑽': '&#38;#119933;', '𝑾': '&#38;#119934;', '𝑿': '&#38;#119935;', '𝒀': '&#38;#119936;', '𝒁': '&#38;#119937;', '𝔄': '&#38;#120068;', '𝔅': '&#38;#120069;', '𝔇': '&#38;#120071;', '𝔈': '&#38;#120072;', '𝔉': '&#38;#120073;', '𝔊': '&#38;#120074;', '𝔍': '&#38;#120077;', '𝔎': '&#38;#120078;', '𝔏': '&#38;#120079;', '𝔐': '&#38;#120080;', '𝔑': '&#38;#120081;', '𝔒': '&#38;#120082;', '𝔓': '&#38;#120083;', '𝔔': '&#38;#120084;', '𝔖': '&#38;#120086;', '𝔗': '&#38;#120087;', '𝔘': '&#38;#120088;', '𝔙': '&#38;#120089;', '𝔚': '&#38;#120090;', '𝔛': '&#38;#120091;', '𝔜': '&#38;#120092;', '𝕬': '&#38;#120172;', '𝕭': '&#38;#120173;', '𝕮': '&#38;#120174;', '𝕯': '&#38;#120175;', '𝕰': '&#38;#120176;', '𝕱': '&#38;#120177;', '𝕲': '&#38;#120178;', '𝕳': '&#38;#120179;', '𝕴': '&#38;#120180;', '𝕵': '&#38;#120181;', '𝕶': '&#38;#120182;', '𝕷': '&#38;#120183;', '𝕸': '&#38;#120184;', '𝕹': '&#38;#120185;', '𝕺': '&#38;#120186;', '𝕻': '&#38;#120187;', '𝕼': '&#38;#120188;', '𝕽': '&#38;#120189;', '𝕾': '&#38;#120190;', '𝕿': '&#38;#120191;', '𝖀': '&#38;#120192;', '𝖁': '&#38;#120193;', '𝖂': '&#38;#120194;', '𝖃': '&#38;#120195;', '𝖄': '&#38;#120196;', '𝖅': '&#38;#120197;', '𝕒': '&#38;#120146;', '𝕓': '&#38;#120147;', '𝕔': '&#38;#120148;', '𝕕': '&#38;#120149;', '𝕖': '&#38;#120150;', '𝕗': '&#38;#120151;', '𝕘': '&#38;#120152;', '𝕙': '&#38;#120153;', '𝕚': '&#38;#120154;', '𝕛': '&#38;#120155;', '𝕜': '&#38;#120156;', '𝕝': '&#38;#120157;', '𝕞': '&#38;#120158;', '𝕟': '&#38;#120159;', '𝕠': '&#38;#120160;', '𝕡': '&#38;#120161;', '𝕢': '&#38;#120162;', '𝕣': '&#38;#120163;', '𝕤': '&#38;#120164;', '𝕥': '&#38;#120165;', '𝕦': '&#38;#120166;', '𝕧': '&#38;#120167;', '𝕨': '&#38;#120168;', '𝕩': '&#38;#120169;', '𝕪': '&#38;#120170;', '𝕫': '&#38;#120171;','𝚊': '&#38;#120458;', '𝚋': '&#38;#120459;', '𝚌': '&#38;#120460;', '𝚍': '&#38;#120461;', '𝚎': '&#38;#120462;', '𝚏': '&#38;#120463;', '𝚐': '&#38;#120464;', '𝚑': '&#38;#120465;', '𝚒': '&#38;#120466;', '𝚓': '&#38;#120467;', '𝚔': '&#38;#120468;', '𝚕': '&#38;#120469;', '𝚖': '&#38;#120470;', '𝚗': '&#38;#120471;', '𝚘': '&#38;#120472;', '𝚙': '&#38;#120473;', '𝚚': '&#38;#120474;', '𝚛': '&#38;#120475;', '𝚜': '&#38;#120476;', '𝚝': '&#38;#120477;', '𝚞': '&#38;#120478;', '𝚟': '&#38;#120479;', '𝚠': '&#38;#120480;', '𝚡': '&#38;#120481;', '𝚢': '&#38;#120482;', '𝚣': '&#38;#120483;', '𝒶': '&#38;#119990;', '𝒷': '&#38;#119991;', '𝒸': '&#38;#119992;', '𝒹': '&#38;#119993;', '𝒻': '&#38;#119995;', '𝒽': '&#38;#119997;', '𝒾': '&#38;#119998;', '𝒿': '&#38;#119999;', '𝓀': '&#38;#120000;', '𝓁': '&#38;#120001;', '𝓂': '&#38;#120002;', '𝓃': '&#38;#120003;', '𝓅': '&#38;#120005;', '𝓆': '&#38;#120006;', '𝓇': '&#38;#120007;', '𝓈': '&#38;#120008;', '𝓉': '&#38;#120009;', '𝓊': '&#38;#120010;', '𝓋': '&#38;#120011;', '𝓌': '&#38;#120012;', '𝓍': '&#38;#120013;', '𝓎': '&#38;#120014;', '𝓏': '&#38;#120015;', '𝓪': '&#38;#120042;', '𝓫': '&#38;#120043;', '𝓬': '&#38;#120044;', '𝓭': '&#38;#120045;', '𝓮': '&#38;#120046;', '𝓯': '&#38;#120047;', '𝓰': '&#38;#120048;', '𝓱': '&#38;#120049;', '𝓲': '&#38;#120050;', '𝓳': '&#38;#120051;', '𝓴': '&#38;#120052;', '𝓵': '&#38;#120053;', '𝓶': '&#38;#120054;', '𝓷': '&#38;#120055;', '𝓸': '&#38;#120056;', '𝓹': '&#38;#120057;', '𝓺': '&#38;#120058;', '𝓻': '&#38;#120059;', '𝓼': '&#38;#120060;', '𝓽': '&#38;#120061;', '𝓾': '&#38;#120062;', '𝓿': '&#38;#120063;', '𝔀': '&#38;#120064;', '𝔁': '&#38;#120065;', '𝔂': '&#38;#120066;', '𝔃': '&#38;#120067;', '𝐚': '&#38;#119834;', '𝐛': '&#38;#119835;', '𝐜': '&#38;#119836;', '𝐝': '&#38;#119837;', '𝐞': '&#38;#119838;', '𝐟': '&#38;#119839;', '𝐠': '&#38;#119840;', '𝐡': '&#38;#119841;','𝐢': '&#38;#119842;', '𝐣': '&#38;#119843;', '𝐤': '&#38;#119844;', '𝐥': '&#38;#119845;', '𝐦': '&#38;#119846;', '𝐧': '&#38;#119847;', '𝐨': '&#38;#119848;', '𝐩': '&#38;#119849;', '𝐪': '&#38;#119850;', '𝐫': '&#38;#119851;', '𝐬': '&#38;#119852;', '𝐭': '&#38;#119853;', '𝐮': '&#38;#119854;', '𝐯': '&#38;#119855;', '𝐰': '&#38;#119856;', '𝐱': '&#38;#119857;', '𝐲': '&#38;#119858;', '𝐳': '&#38;#119859;', '𝑎': '&#38;#119886;', '𝑏': '&#38;#119887;', '𝑐': '&#38;#119888;', '𝑑': '&#38;#119889;', '𝑒': '&#38;#119890;', '𝑓': '&#38;#119891;', '𝑔': '&#38;#119892;', '𝑖': '&#38;#119894;', '𝑗': '&#38;#119895;', '𝑘': '&#38;#119896;', '𝑙': '&#38;#119897;', '𝑚': '&#38;#119898;', '𝑛': '&#38;#119899;', '𝑜': '&#38;#119900;', '𝑝': '&#38;#119901;', '𝑞': '&#38;#119902;', '𝑟': '&#38;#119903;', '𝑠': '&#38;#119904;', '𝑡': '&#38;#119905;', '𝑢': '&#38;#119906;', '𝑣': '&#38;#119907;', '𝑤': '&#38;#119908;', '𝑥': '&#38;#119909;', '𝑦': '&#38;#119910;', '𝑧': '&#38;#119911;', '𝒂': '&#38;#119938;', '𝒃': '&#38;#119939;', '𝒄': '&#38;#119940;', '𝒅': '&#38;#119941;', '𝒆': '&#38;#119942;', '𝒇': '&#38;#119943;', '𝒈': '&#38;#119944;', '𝒉': '&#38;#119945;', '𝒊': '&#38;#119946;', '𝒋': '&#38;#119947;', '𝒌': '&#38;#119948;', '𝒍': '&#38;#119949;', '𝒎': '&#38;#119950;', '𝒏': '&#38;#119951;', '𝒐': '&#38;#119952;', '𝒑': '&#38;#119953;', '𝒒': '&#38;#119954;', '𝒓': '&#38;#119955;', '𝒔': '&#38;#119956;', '𝒕': '&#38;#119957;', '𝒖': '&#38;#119958;', '𝒗': '&#38;#119959;', '𝒘': '&#38;#119960;', '𝒙': '&#38;#119961;', '𝒚': '&#38;#119962;', '𝒛': '&#38;#119963;', '𝔞': '&#38;#120094;', '𝔟': '&#38;#120095;', '𝔠': '&#38;#120096;', '𝔡': '&#38;#120097;', '𝔢': '&#38;#120098;', '𝔣': '&#38;#120099;', '𝔤': '&#38;#120100;', '𝔥': '&#38;#120101;', '𝔦': '&#38;#120102;', '𝔧': '&#38;#120103;', '𝔨': '&#38;#120104;', '𝔩': '&#38;#120105;', '𝔪': '&#38;#120106;', '𝔫': '&#38;#120107;', '𝔬': '&#38;#120108;', '𝔭': '&#38;#120109;', '𝔮': '&#38;#120110;', '𝔯': '&#38;#120111;', '𝔰': '&#38;#120112;', '𝔱': '&#38;#120113;', '𝔲': '&#38;#120114;', '𝔳': '&#38;#120115;', '𝔴': '&#38;#120116;', '𝔵': '&#38;#120117;', '𝔶': '&#38;#120118;', '𝔷': '&#38;#120119;', '𝖆': '&#38;#120198;', '𝖇': '&#38;#120199;', '𝖈': '&#38;#120200;', '𝖉': '&#38;#120201;', '𝖊': '&#38;#120202;', '𝖋': '&#38;#120203;', '𝖌': '&#38;#120204;', '𝖍': '&#38;#120205;', '𝖎': '&#38;#120206;', '𝖏': '&#38;#120207;', '𝖐': '&#38;#120208;', '𝖑': '&#38;#120209;', '𝖒': '&#38;#120210;', '𝖓': '&#38;#120211;', '𝖔': '&#38;#120212;', '𝖕': '&#38;#120213;', '𝖖': '&#38;#120214;', '𝖗': '&#38;#120215;', '𝖘': '&#38;#120216;', '𝖙': '&#38;#120217;', '𝖚': '&#38;#120218;', '𝖛': '&#38;#120219;', '𝖜': '&#38;#120220;', '𝖝': '&#38;#120221;', '𝖞': '&#38;#120222;', '𝖟': '&#38;#120223;', '𝙼':'&#38;#120444;'}

    panos = input("Text:")
    TextFont = input("Номер шрифта")
    dest = fonts[TextFont]
    s = ''.join(translit.get(c, c) for c in panos)
    msg = u''.join(dict(zip(eng, dest)).get(c, c) for c in s)
    msgfix=  ''.join(fix.get(a, a) for a in msg)
    print(msgfix)
    time.sleep(2.5)
    main()

def other():
    print(othering[0])
    otheringVibor = input("[+] ► ")
    proxydir = os.path.join("Proxies")
    if not os.path.exists(proxydir):
        os.makedirs("Proxies")

    if otheringVibor == "1":
        url = 'http://foxtools.ru/Proxy'
        get_html(html(url))

    if otheringVibor == "2":
        print(list_proxy[0])
        listProxy = input("[+] ► ")

        if listProxy == "1":
            socks5 = requests.get("https://api.proxyscrape.com/?request=displayproxies&proxytype=socks5&timeout=10000&country=all&anonymity=all&ssl=all")
            httpSave = open("Proxies/socks5.txt","w")
            httpsSaves = httpSave.write(str(socks5.text))
            print(socks5.text)
            console.log("[bold green]Прокси успешно записаны!В файл socks5.txt")

        if listProxy == "2":
            socks4 = requests.get("https://api.proxyscrape.com/?request=displayproxies&proxytype=socks4&timeout=10000&country=all&anonymity=all&ssl=all")
            httpSave = open("Proxies/socks4.txt","w")
            httpsSaves = httpSave.write(str(socks4.text))
            print(socks4.text)
            console.log("[bold green]Прокси успешно записаны!В файл socks4.txt")

        if listProxy == "3":
            httpsS = requests.get("https://api.proxyscrape.com/?request=displayproxies&proxytype=https(s)&timeout=10000&country=all&anonymity=all&ssl=all")
            httpsSave = open("Proxies/HTTPS(S).txt","w")
            httpsSaves = httpsSave.write(str(httpsS.text))
            print(httpsS.text)
            console.log("[bold green]Прокси успешно записаны!В файл HTTPS(S).txt")

    if otheringVibor == "3":
        font()

    if otheringVibor == "4":
        text = input("Text [+] ► ")
        b = text.encode("UTF-8")
        e = base64.b64encode(b)
        print(e)
    if otheringVibor == "5":
        text = input("Text [+] ► ")
        b1 = text.encode("UTF-8")
        d = base64.b64decode(b1)
        s2 = d.decode("UTF-8")
        print(s2)
def main():
    print(hello[0] + scripts[0])
    vibor = input("[+] ► ")
    if vibor == "1":
        porting() 
    if vibor == "2":
        raidbot()
    if vibor == "3":
        deanons()
    if vibor == "4":
        vktools()
    if vibor == "5":
        dos.pizda()
    if vibor == "7":
        other()
    if vibor == "99":
        os.system("exit")
        console.log(f"[bold red]\033[35m Спасибо за использования скрипта!")

if __name__ == '__main__':
	main()